package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;;
public class PayrollServicesImpl {


	private PayrollDAOServicesImpl daoServices;
	public PayrollServicesImpl(){
		daoServices= new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails(String firstName, String lastName,
			String department, String designation, String pancard, String emailId,int accountNumber, String bankName, String ifscCode,int basicSalary,
			int yearlyInvestmentUnder80C,int epf,int companyPf){
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf),new BankDetails(accountNumber, bankName, ifscCode)));
	}


	public int calculateNetSalary(int associateID){
		float tax;
		Associate associate=this.getAssociateDetails(associateID);
		if(associate!=null){

			associate.getSalary().setPersonalAllowance((float) (0.3* associate.getSalary().getBasicSalary()));
			associate.getSalary().setHra((float) (0.25*associate.getSalary().getBasicSalary()));
			associate.getSalary().setConveyenceAllowance((float) (0.20*associate.getSalary().getBasicSalary()));
			associate.getSalary().setOtherAllowance((float) (0.10*associate.getSalary().getBasicSalary()));
			associate.getSalary().setGratuity((float) (0.5*associate.getSalary().getBasicSalary()));
			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getCompanyPf()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getHra());
			float annualSalary=(associate.getSalary().getGrossSalary()*12);

			float 	j=associate.getYearlyInvestmentUnder80C()+12*(associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());	
			if(j>=150000){
				j=150000;
			}
			if(annualSalary<250000){
				associate.getSalary().setMonthlyTax(0);
				associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
				return (int) (associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
			}
			else if(annualSalary>=250000&&annualSalary<500000){
				float 	i=(annualSalary-250000-j);
				
				if(i<=0)
					tax=0;
				else
					tax=(int) ((0.1*i)/12);
				associate.getSalary().setMonthlyTax(tax);
				associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
				return (int) (associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
			}
			
			else if(annualSalary>=1000000){
				float 	i=(float) ((250000-j)*0.1);
				 	tax=(float) ((i+100000+((annualSalary-1000000)*0.3))/12);
				associate.getSalary().setMonthlyTax(tax);
				associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
				return (int) (associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
			}
			else	if(annualSalary>=500000&&annualSalary<1000000){
				float 	i=(float) ((250000-j)*0.1);
				 	tax=(float) ((((annualSalary-500000)*0.2)+i)/12);
				associate.getSalary().setMonthlyTax(tax);
				associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
				return (int) (associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-tax);
			}
			
		}
		
			return 0;
	
		
	}
	public Associate getAssociateDetails(int associateId){
		return daoServices.getAssociate(associateId);
	}
	public Associate[] getAllAssociateDetails(){
		return daoServices.getAssociate();
	}
}
