package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

public static void main(String[] args) {
	PayrollServicesImpl payrollServices=new PayrollServicesImpl();
	int associateID=payrollServices.acceptAssociateDetails("Divya", "Changa", "SoftWare", "Analyst", "AWT123", "divya@abc.com", 1234, "yahoo", "yahoo123", 15000, 120000, 1000, 1000);
	System.out.println(associateID);
	System.out.println(payrollServices.getAssociateDetails(associateID).getFirstName());
	System.out.println(payrollServices.calculateNetSalary(associateID));
	System.out.println(payrollServices.getAssociateDetails(associateID).getSalary().getMonthlyTax());
	//payrollServices.calculateNetSalary(associateID);
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*String firstNameToBeSearch="satish";
			Associate associate=	searchAssociate("firstNameToBeSearch");
			if(associate!=null)
				System.out.println(associate.getFirstName()+" "+associate.getLastName());
			else
				System.out.println("associate details with ID"+firstNameToBeSearch +"NotFound");
	}
			public static Associate searchAssociate(String firstName){
		        Associate[] associates=new Associate[3];*/
				// Associate associate=new Associate(1234, 1000, "divya", "teja", "software", "analyst", "abcdefgh", "sweet@abc.com",new Salary(10000, 1000, 3000, 5000, 4000, 4000, 3000, 5000, 6000, 9000, 8000),new BankDetails(0001, "Abc", "ab12"));
				 /*for (Associate associate:associates)
					if(associates!=null && associate.getYearlyInvestmentUnder80C()==50000 )
						return associate;
						return null;*/
				//Salary salary1=new Salary(10000,1000,1000,1000,1000,1000,1000,1000,1000,10000,11000);
				//Salary salary2=new Salary(11000,1000,1000,1000,1000,1000,1000,1000,1000,10000,12000);
				//Salary salary3=new Salary(13000,1000,1000,1000,1000,1000,1000,1000,1000,10000,13000);
				//System.out.println(associate.getSalary().getBasicSalary());
				//BankDetails bankdetail1=new BankDetails(1001,"abc","a123");
				//BankDetails bankdetail2=new BankDetails(1002,"abc","a123");
				//BankDetails bankdetail3=new BankDetails(1003,"abc","a123");
				//System.out.println("AccountNumber: "+bankdetail1.getAccountNumber()+"Bank Name: "+bankdetail1.getBankName()+"IFSC Code:"+bankdetail1.getIfscCode());
				//System.out.println("AccountNumber: "+bankdetail2.getAccountNumber()+"Bank Name: "+bankdetail2.getBankName()+"IFSC Code:"+bankdetail2.getIfscCode());
				//System.out.println("AccountNumber: "+bankdetail3.getAccountNumber()+"Bank Name: "+bankdetail3.getBankName()+"IFSC Code:"+bankdetail3.getIfscCode());
				
	}
}		
	
